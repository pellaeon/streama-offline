//# sourceMappingURL=admin-ctrl.js.map
angular.module("streama").controller("adminCtrl",["$scope","apiService","modalService","$rootScope",function(a,b,c,d){}]);