//# sourceMappingURL=settings-ctrl.js.map
angular.module("streama").controller("settingsCtrl",["$scope","apiService","modalService","$rootScope",function(a,b,c,d){}]);