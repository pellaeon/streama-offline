//# sourceMappingURL=user-service.js.map
angular.module("streama").factory("userService",["$rootScope","$translate",function(a,c){return{setCurrentUser:function(b){a.currentUser=b}}}]);